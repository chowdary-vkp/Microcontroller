fw_main,c8322b217b8cb4a6d8386e7ab2b9fd2a,/usr/bin/
gpio_reset,4f16a23bffcc2cbd7cd81208264c07b6,/usr/bin/
mount.service,b4cad09de6419d382aebc49e82749b67,/etc/systemd/system/
phone.wav,c78d1c3e4dd13d189eeb1d040a38aefd,/root/
sos_notification.wav,9c5134833be1f7d84807da988fc05f36,/root/
ssh.sh,4b2092a9219364747929b385061e7f72,/usr/bin/
SW_RX,1ae7d9f4658b1fcd242f32651a744341,/root/
