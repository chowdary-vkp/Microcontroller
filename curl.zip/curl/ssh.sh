#!/bin/bash

file="/usr/bin/gpio_reset"
if [ -f "$file" ]; then
    chmod +x "$file"  # Ensure the file is executable if needed
    "$file"  # Execute the file
else
    echo "File $file does not exist."
    # Handle the case when the file does not exist, if needed
fi

insmod /lib/modules/`uname -r`/kernel/drivers/usb/gadget/legacy/g_ether.ko
sleep 2
ifconfig usb0 192.168.3.11 up
sleep 4
aplay -D plughw:2,0 /root/phone.wav
sleep 1
